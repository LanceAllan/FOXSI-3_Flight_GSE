/*
 *  data.cpp
 *  FOXSI_GSE
 *
 *  Created by Steven Christe on 10/31/11.
 *  Copyright 2011 NASA GSFC. All rights reserved.
 *
 *	pthread tutorial
 *	https://computing.llnl.gov/tutorials/pthreads/#ConVarSignal
 *
 */
#include "Application.h"

#include "data.h"
#include "threads.h"
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>

#include "gui.h"
#include "usbd2xx.h"
#include "okFrontPanelDLL.h"
#include "telemetry.h"

#define MAXPATH 128
#define NUM_THREADS 8
#define XSTRIPS 128
#define YSTRIPS 128
#define MAX_CHANNEL 1024
#define FORMATTER_CONFIGURATION_FILE "gsesync.bit"

extern long HistogramFunction[MAX_CHANNEL];
extern long Histogram_database[261][MAX_CHANNEL];
extern double detImage[XSTRIPS][YSTRIPS];
extern double detImagetime[XSTRIPS][YSTRIPS];
extern double detImagemask[XSTRIPS][YSTRIPS];
extern int low_threshold;

// Note that an unsigned short int is 2 bytes
// for formatter
// #define FRAME_SIZE_IN_SHORTINTS 295
// #define FRAME_SIZE_IN_BYTES 590

// for ASIC
#define FRAME_SIZE_IN_SHORTINTS 784
#define FRAME_SIZE_IN_BYTES 1568

extern Gui *gui;

char dataFilename[MAXPATH];
FILE *dataFile;

okCFrontPanel *dev;

int newdisplay;
int stop_message;
int histogram_asic;
int stripNumber;
time_t start_time;
time_t current_time;

extern int data_source;
unsigned short int buffer[FRAME_SIZE_IN_SHORTINTS];
unsigned short int buffer0[FRAME_SIZE_IN_SHORTINTS];
unsigned short int framecount;

unsigned short int attempt[FRAME_SIZE_IN_SHORTINTS];

extern unsigned int current_timebin;
extern unsigned int LightcurveFunction[MAX_CHANNEL];

int *taskids[NUM_THREADS];
int fout;
pthread_mutex_t mymutex;
pthread_mutex_t timebinmutex;
double nreads;

extern char *data_file_save_dir;
extern int file_type;

void data_initialize(void)
{
	// Initialize a connection to a data stream
    
	// Read the data source from the preferences
	gui->prefs->get("data_source", data_source, 0);
    
	if (data_source == 0)
	{
		gui->app->print_to_console("Initializing Simulated data.\n");
		gui->startReadingDataButton->activate();
        gui->closeBut->activate();
        gui->initializeBut->deactivate();
		gui->app->flush_image();
		gui->app->flush_histogram();
		gui->app->flush_timeseries();
		gui->app->print_to_console("Done initializing.\n");
		
	}
	
	if (data_source == 1)
	{
		gui->app->print_to_console("Initializing USB/ASIC connection.\n");
		if (gui->usb->open(0) < 0)
		{
			gui->app->print_to_console("Could not open device.\n");
			gui->app->print_to_console("Initialization Failed!\n");
		}
		else
		{		
			gui->startReadingDataButton->activate();
			gui->closeBut->activate();
            gui->initializeBut->deactivate();
			gui->sendParamsWindow_sendBut->activate();
			gui->setHoldTimeWindow_setBut->activate();
			gui->setHoldTimeWindow_autorunBut->activate();
			gui->app->flush_image();
			gui->app->flush_histogram();
			gui->app->flush_timeseries();
            gui->app->flush_frame();
			gui->app->print_to_console("Done initializing.\n");
		}

	}
	
	if (data_source == 2)
	{
		char dll_date[32], dll_time[32];
		int init_state = 1;
		
		gui->app->print_to_console("Initializing USB/Formatter connection.\n");

		if (FALSE == okFrontPanelDLL_LoadLib(NULL)) 
		{
			gui->app->print_to_console("FrontPanel DLL could not be loaded.\n");
			init_state = 0;
		}
		okFrontPanelDLL_GetVersion(dll_date, dll_time);
		printf("FrontPanel DLL loaded.Built: %s %s\n", dll_date, dll_time);
		
		okCFrontPanel *devi = data_initialize_formatter_FPGA();
		if (NULL == devi) 
		{
			gui->app->print_to_console("FPGA could not be initialized.\n");
			gui->app->print_to_console("Initialization Failed!\n");
			init_state = 0;
		}
		
		if (init_state == 1){
			gui->startReadingDataButton->activate();
			gui->closeBut->activate();
            gui->initializeBut->deactivate();
			gui->detector_choice->activate();
			gui->app->print_to_console("Done initializing.\n");
		} else gui->app->print_to_console("Initialization failed!\n");
	}
}

void* data_watch_buffer(void* p)
{
	/* Watches the buffer variable for changes. When changes occur, parse 
	 * the buffer variable into a data packet and update the display.
	 */
	
	// This function never stops unless told to do so by setting stop_message to 1
	while(1)
	{
		if (newdisplay == 1 and pthread_mutex_trylock( &mymutex) == 0){
        
            // update the display
            Fl::lock();
            if (gui->writeFileBut->value() == 1){
                data_frame_print_to_file(buffer0);
            }
            data_update_display(buffer0);
            
            newdisplay = 0;
            fflush(stdout);
            
            pthread_mutex_unlock(&mymutex);
    
            gui->mainHistogramWindow->redraw();
            gui->mainImageWindow->redraw();
            gui->mainLightcurveWindow->redraw();
            Fl::awake(); // Without this it may not redraw until next event (like a mouse movement)!
        
            Fl::unlock();
        }
		
		if (stop_message == 1){
			pthread_exit(NULL);
		}
	}
}

void* data_timer(void *p)
{
	/* Keep track of the timer */
  //  long temp_time = start_time;
	while(1)
	{
        
		// a sleep statement so that it does not pole the time too often
		// more often than is necessary
		usleep(0.5/1000000.0);
        current_time = time(NULL);
        //start_time could get overwritten, the following prevents that
  //      start_time = temp_time;
        gui->app->elapsed_time_sec = difftime(time(NULL), start_time);
		if (stop_message == 1){
			pthread_exit(NULL);}
	}
}

void* data_countrate(void *p)
{
	/* Keep track of the timer */
	//unsigned int i = 1;
    
	while(1)
	{
		int microseconds;
		microseconds = gui->mainLightcurveWindow->binsize[0]*1000000.0;
		
		// System activity may lengthen the sleep by an indeterminate amount.
		// therefore this is not the best way to measure count rate
		// quick and dirty
		usleep(microseconds);
        
		pthread_mutex_lock(&timebinmutex);
		
		LightcurveFunction[0] = current_timebin;
		
		for(int j = MAX_CHANNEL-1; j > 0; j--){ 
			LightcurveFunction[j] = LightcurveFunction[j-1];
			gui->mainLightcurveWindow->binsize[j] = gui->mainLightcurveWindow->binsize[j-1];
		}
		
		current_timebin = 0;
		pthread_mutex_unlock(&timebinmutex);
		
		if (stop_message == 1){
			pthread_exit(NULL);}		
	}
	
}

void* data_read_data(void *p)
{
	/* Read the data in continuously. A data frame is read into the buffer 
	 * variable and written to disk (if a file has been opened), 
	 * and then copied into the buffer0 variable. This variable is being watched 
	 * by data_watch_buffer which uses it to update the displays.
	 */
	ssize_t wlen;
	long len;
	int badSync = 0;
	int badRead = 0;
	int status = 0;
	char buffer[50];

	int maxreads;
	maxreads = gui->nEvents->value();
    
    FILE *temp;
    temp = dataFile;
    
    char tempName[MAXPATH];
    for (int i=0; i<MAXPATH; i++)
        tempName[i] = dataFilename[i];
    
	// Read the read delay from the preferences
	int read_delay;
	gui->prefs->get("read_delay", read_delay, 0);
	
	// Read the data source from the preferences.
	gui->prefs->get("data_source", data_source, 0);
	
	// Check to see if a file is open and write header to it before starting
	// to write data to it
	if((dataFile != NULL) && (data_source == 1))
	{
		gui->usb->writeHeader(dataFile);
	}
    int aa = 0;
    int iteration = 200;
    
	// This function never stops unless told to do so by setting stop_message to 1
	while (1) {
		// For the desired reading speed
      
		if (read_delay != 0) {usleep(read_delay);}
    
        aa++;
     
        // read the data
		if (data_source == 0){
			// read from the simulation
			data_simulate_data();
		}
	
		if (data_source == 1) {
            // read from the USB/ASIC
           
            if(aa % iteration == 0)
            {
                gui->usb->close(1);
                gui->usb->open(1);
            }
           
			status = gui->usb->findSync();
			if(status<1){  
                if(status == -1)
                {
                    gui->usb->close(1);
                    gui->usb->open(1);
                }
				badSync++;
				continue;
			}
            
            if(pthread_mutex_trylock(&mymutex) == 0){
                status = gui->usb->readFrame();
              //  int frame = gui->framenumCounter->value();
              //  frame++;
              //  gui->framenumCounter->value(gui->framenumCounter->value()+1);
                pthread_mutex_unlock(&mymutex);
            }
			if(status<1){
				badRead++;
				continue;
			}
		}
    
		if (data_source == 2){
			// read from the USB/Formatter, reads 4 frames at a time.
			len = dev->ReadFromBlockPipeOut(0xA0,1024,2048,(unsigned char *) buffer);
		}
	
		if(fout > 0)
		{
			if( (wlen = write(fout,(const void *) buffer,FRAME_SIZE_IN_BYTES) ) != FRAME_SIZE_IN_BYTES){};
		}
	
        if (pthread_mutex_trylock(&mymutex) == 0) // if fail missed as main hasn't finished
		{
			if (newdisplay == 0)
			{
				memcpy((void *) buffer0,(void *) buffer,FRAME_SIZE_IN_BYTES);
				newdisplay = 1;
			}
			pthread_mutex_unlock(&mymutex);
		}
	
		// Check to see if if only a fixed number of frames should be read
		// if so set the stop message
		if ((maxreads != 0) && (nreads >= maxreads)){
			stop_message = 1;
		}
    
		if (stop_message == 1){
            //something overrides the dataFile path and name in the above part of the while loop
            // this gives back the original path
            dataFile = temp;
            for(int i=0; i<MAXPATH; i++)
                dataFilename[i] = tempName[i];
            
			Fl::lock();
			gui->app->print_to_console("Read finished or stopped.\n");
            
			if (data_source == 1) {
				sprintf(buffer, "%d bad syncs, %d bad reads.\n", badSync, badRead);
				gui->consoleBuf->insert(buffer);						
			}
			gui->stopReadingDataButton->deactivate();
			gui->startReadingDataButton->activate();
			gui->writeFileBut->value(0);
			gui->closeBut->activate();
			
            if(nreads > maxreads-1){
				//gui->nEventsDone->value(0);
				nreads = 0;
			}

			Fl::unlock();
            
			if (fout > 0){
				gui->app->printf_to_console("Closing file: %s.\n", dataFilename, NULL);
				close(fout);
			}
			if (dataFile != NULL){
				gui->app->printf_to_console("Closing file: %s.\n", dataFilename, NULL);
				fclose(dataFile);
			}
			
			if (data_source == 1)
			{
				//cleam up usb interface
			}
			if (data_source == 2) {
				//clean up formatter interface
			}
			
			pthread_mutex_destroy(&mymutex);
			pthread_mutex_destroy(&timebinmutex);
			pthread_exit(NULL);
		}
        nreads++;
	}
}

void data_simulate_data(void)
{
	// Add some delay for the actual read
	usleep(100);
	
	framecount++;
	
	unsigned short int tempx;
	unsigned short int tempy;
	unsigned short int tempenergy;

	struct voltage_data {
		unsigned value: 12;
		unsigned status: 4;
	};
	
	strip_data strip;
	voltage_data volt;
	
	struct strip_data  // 2 bytes
	{
		unsigned data : 10;
		unsigned number : 6;
	};
		
	buffer[0] = 60304; 	// Sync 1 - Hex EB90 - missing in formatter data
	buffer[0] = 63014;  // Sync 2 - Hex F626
	buffer[1] = (unsigned short int) (arc4random() % 100); 	// Time 1 (MSB)
	buffer[2] = (unsigned short int) (arc4random() % 100); 	// Time 2 (MSB)
	buffer[3] = (unsigned short int) (arc4random() % 100); 	// Time 3 (LSB)
	buffer[4] = framecount; 	// Frame Counter 1
	buffer[5] = framecount;		// Frame Counter 2
	// 7 Housekeeping 0
	// 8 Cmd Count
	// 9 Command 1
	// 10 Command 2
	// 11 Housekeeping 1
	// 12 Formatter Status
	// 13 0
	volt.value = telemetry_voltage_convert_hvvalue(250);
	volt.status = 4;
	memcpy(&buffer[13],&volt,2);
	
	// 14 HV value/status
	// 15 Housekeeping 2
	// 16 Status 0
	// 17 Status 1
	// 18 Status 2
	// 19 Housekeeping 3
	// 20 Status 3
	// 21 Status 4
	// 22 Status 5
	// 23 Status 6
	// 24 Detector 0 Time
	buffer[25] = (unsigned short int) (arc4random()); // 25 0ASIC0 mask0
	buffer[26] = (unsigned short int) (arc4random()); // 26 0ASIC0 mask1
	buffer[27] = (unsigned short int) (arc4random()); // 27 0ASIC0 mask2
	buffer[28] = (unsigned short int) (arc4random()); // 28 0ASIC0 mask3
	// 29 0Strip0A Energy
	
	// Choose some random pixels to light up
	tempx = (arc4random() % 128 + 1);
	tempy = (arc4random() % 128 + 1);
	tempenergy = (arc4random() % MAX_CHANNEL + 1);

	// if (tempx < 64){ buffer[25] = ~(~0 << 1) << (tempx - 
	
	strip.data = tempx;
	strip.number = tempenergy;
	memcpy(&buffer[29],&strip,2);
	// 30 0Strip0B Energy
}

void data_start_file(void)
{
	/* Open a file to write the data to. The file pointer is set to fout.
	 * 
	 */

	// the following variables holds the fully qualified filename (dir + filename)
	// if directory NOT set then will create file inside of current working directory
	// which is likely <foxsi gse dir>/build/Debug/
	
	if (gui->writeFileBut->value() == 1) {
		data_set_datafilename();
		gui->app->printf_to_console("Trying to open file: %s\n", dataFilename, NULL);
		if (gui->fileTypeChoice->value() == 0) {
			dataFile = fopen(dataFilename, "w");
			
			if (dataFile == NULL)
				gui->app->printf_to_console("Cannot open file %s.\n", dataFilename, NULL); 
			else 
				gui->app->printf_to_console("Opened file %s.\n", dataFilename, NULL);
			
			//gui->app->write_header(dataFile);
			
		}
		if (gui->fileTypeChoice->value() == 1) {
			if((fout = open(dataFilename,O_RDWR|O_CREAT,0600)) < 0){
				gui->app->printf_to_console("Cannot open file %s.\n", dataFilename, NULL);}
			else {
				gui->app->printf_to_console("Opened file %s.\n", dataFilename, NULL);
			}
			
		}
		
	} else {
		gui->app->printf_to_console( "Closing file %s.\n", dataFilename, NULL);
		if (gui->fileTypeChoice->value() == 1){close(fout);}
		if (gui->fileTypeChoice->value() == 0){fclose(dataFile);}
		fout = 0;
	}
}

void data_start_reading(void)
{
	pthread_t thread;
    struct sched_param param;
    pthread_attr_t tattr;
	
	int *variable;
	int ret;
    gui->app->flush_frame();
	gui->stopReadingDataButton->activate();
	
	stop_message = 0;
	start_time = time(NULL);
	
	// define a high (custom) priority for the read_data thread
    int newprio = -10;
	param.sched_priority = newprio;
	ret = pthread_attr_init(&tattr);
	ret = pthread_attr_setschedparam (&tattr, &param);
		
	gui->app->print_to_console("Reading...\n");
	
	// start the read_data thread
	ret = pthread_create(&thread, &tattr, data_read_data, (void *) taskids[0]);
	pthread_mutex_init(&mymutex,NULL);
	pthread_mutex_init(&timebinmutex,NULL);

	//newprio = -5;
	//param.sched_priority = newprio;
	//ret = pthread_attr_init(&tattr);
	//ret = pthread_attr_setschedparam (&tattr, &param);
	
	// start the watch_buffer thread
	ret = pthread_create(&thread, NULL, data_watch_buffer, (void *) taskids[1]);
	
	//newprio = -5;
	//param.sched_priority = newprio;
	//ret = pthread_attr_init(&tattr);
	//ret = pthread_attr_setschedparam (&tattr, &param);
	
	// start the data reading clock
	ret = pthread_create(&thread, NULL, data_timer, (void *) taskids[2]);
	// start the count rate thread
	ret = pthread_create(&thread, NULL, data_countrate, (void *) taskids[3]);
}

void data_stop_reading(void)
{
	stop_message = 1;	
}

void data_frame_print_to_file(unsigned short int *frame)
{
	if (data_source == 1)
	{
		gui->usb->writeFrame(dataFile);
	}
}

void data_update_display(unsigned short int *frame)
{
	// Parse the buffer variable and update the display
	// reading from the ASIC one frame at a time
	// reading from the Formater four frames at a time
	unsigned short int strip_data;
	unsigned short int strip_number;

    int ymask[128] = {0};
    int xmask[128] = {0};
    int xstrips[128] = {0};
    int ystrips[128] = {0};
	int num_hits = 0;
  
	gui->nEventsDone->value(nreads);
	
	if (data_source == 0) {

		// if parsing simulated data
		unsigned voltage_status;
		unsigned voltage;
        
		voltage_status = buffer[13] & 0xF;
		voltage = (buffer[13] >> 12) & 0xFFF;
		
        //gui->nEventsDone->value(nreads);
        gui->framenumOutput->value(frame[5]);
        gui->inttimeOutput->value(gui->app->elapsed_time_sec);

		gui->HVOutput->value(voltage);
		if (voltage_status == 1){gui->HVOutput->textcolor(FL_RED);}
		if (voltage_status == 2){gui->HVOutput->textcolor(FL_BLUE);}
		if (voltage_status == 4){gui->HVOutput->textcolor(FL_BLACK);}
		
		num_hits = arc4random() % 10;
		for(int i = 0; i < num_hits; i++)
		{
			int x, y, z;
			// HistogramFunction[strip_data]++;
			x = arc4random() % XSTRIPS + 1;
			y = arc4random() % YSTRIPS + 1;
			z = arc4random() % MAX_CHANNEL + 1;
			HistogramFunction[z] += 1;
            detImage[x][y] = z;
			detImagetime[x][y] = clock();
			//detImagemask[i][j] = getbits(xmask, XSTRIPS/8 - i % (XSTRIPS/8)-1,1) * getbits(ymask, YSTRIPS/8 - j % (YSTRIPS/8)-1,1);
		}
		
		pthread_mutex_lock( &timebinmutex);
		current_timebin+=num_hits;
		pthread_mutex_unlock(&timebinmutex);
	}
	
	if (data_source == 1){
        gui->inttimeOutput->value(gui->app->elapsed_time_sec);
        /*
		// parse and display the data from the USB/ASIC connection
		// order for asics n n then p p
		int index = 0;
        
		// Loop through the 4 ASICS
		for( int j = 0; j < 4; j++)
		{
			printf("ASIC %d frame START ---------------------- \n", j);
            
			// for the other ASICs, it's already in the data stream.
			if(j==0){
				printf( "eb90\n");
			} else{
				printf( "%x\n", frame[index]);	index++;
			}
            
			printf( "frame counter: %u\n", frame[index]);	index++;	//frame counter
			printf( "start bit: %x\n", frame[index]);	index++;	//start
			printf( "chip bit: %x\n", frame[index]);	index++;	//chip
			printf( "trigger bit: %x\n", frame[index]);	index++;	//trigger
			printf( "seu bit: %x\n", frame[index]);	index++;	//seu
			
			// channel mask displayed in hex
			// First two channel mask bits are stored as one word each.
			printf("Channel Mask:\n");
			
			printf( "%x", frame[index]);	index++;	// dummy pedestal
			printf( "%x", frame[index]);	index++;	// common mode bit
			
            
            for(int i=0; i<64; i++)
            {
                xmask[i] = getbits(frame[index],i,1);
                ymask[i] = getbits(frame[index],i,1);
            }
            
			for( int i = 0; i < 8; i++ ){ xmask[i] = getbits(frame[index], i, 1); }
			for( int i = 8; i < 16; i++ ){ xmask[i] = getbits(frame[index], i, 1);}
			for( int i = 16; i < 32; i++ ){ xmask[i] = getbits(frame[index], i, 1);}
			for( int i = 32; i < 64; i++ ){ xmask[i] = getbits(frame[index], i, 1);}
			
            
			printf( "%x", frame[index]);	index++;
			printf( "%x", frame[index]);	index++;
			printf( "%x", frame[index]);	index++;
			printf( "%x\n", frame[index]);	index++;
			
			printf( "Pedestal: %u\n", frame[index]); index++;	//pedestal
			
			printf("Strip Data (%i):\n", index);
			printf( "\nCommon mode %i: %u\n", index+64, frame[index+64]);	//common mode
            
			// strip data
			
			for(int i = 0; i < XSTRIPS/2; i++){
				// strip_data = frame[index] & 0x3ff;
				// strip_number = (frame[index] << 10) & 0x3f;
				strip_data = frame[index] - frame[index+64];
				if (j == 3){if (strip_data > 0){ HistogramFunction[strip_data]++; }}
				
				if (strip_data != 0){
                    if (j < 2){ xstrips[i + j*64] = strip_data; }
					if (j >= 2){ ystrips[i + (j-2)*64] = strip_data; }
				}
				printf( "%u\t", frame[index]);	index++;
			}
            
			printf( "\nCommon mode %i: %u\n", index, frame[index]);	index++;	//common mode
			printf("Readout info:\n");
			// 10 extra words of readout information
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\t", frame[index]);	index++;
			printf( "%u\n", frame[index]);	index++;
			printf("ASIC %u frame END  -------------------------------- \n", j);
		}
        */
        if(attempt[350] != 2989){
            //arrays to store the data for the asics
            int asic0[64] = {0};
            int asic1[64] = {0};
            int asic2[64] = {0};
            int asic3[64] = {0};
       
            //the common mode numbers for the different asics
            int asic0Pedestal = attempt[11];
            int asic1Pedestal = attempt[99];
            int asic2Pedestal = attempt[187];
            int asic3Pedestal = attempt[275];
    
            for(int i = 0; i < 64; i++){
                asic0[i] = attempt[12+i] - asic0Pedestal;
                if(asic0[i] < 0)
                    asic0[i] = 0;
            }
            for(int i = 0; i < 64; i++){
                asic1[i] = attempt[100+i] - asic1Pedestal;
                if(asic1[i] < 0)
                    asic1[i] = 0;
            }
            for(int i = 0; i < 64; i++){
                asic2[i] = attempt[188+i] - asic2Pedestal;
                if(asic2[i] < 0)
                    asic2[i] = 0;
            }
            for(int i = 0; i < 64; i++){
                asic3[i] = attempt[276+i] - asic3Pedestal;
                if(asic3[i] < 0)
                    asic3[i] = 0;
            }
         
            for(int i = 0; i < 64; i++)
            {
                Histogram_database[i][asic0[i]]++;
                Histogram_database[i+64][asic1[i]]++;
                Histogram_database[i+128][asic2[i]]++;
                Histogram_database[i+192][asic3[i]]++;
                Histogram_database[256][asic0[i]]++;
                Histogram_database[256][asic1[i]]++;
                Histogram_database[256][asic2[i]]++;
                Histogram_database[256][asic3[i]]++;
                Histogram_database[257][asic0[i]]++;
                Histogram_database[258][asic1[i]]++;
                Histogram_database[259][asic2[i]]++;
                Histogram_database[260][asic3[i]]++;
            }
            
            if(stripNumber == 0){
                for(int i = 0; i < MAX_CHANNEL; i++){
                    HistogramFunction[i] = Histogram_database[256+histogram_asic][i];
                }
            }
            else {
                int yy = (stripNumber - 1)+(histogram_asic - 1)*64; //so that this calculation is not made 1000 times in the loop
                for(int i = 0; i < MAX_CHANNEL; i++){
                    HistogramFunction[i] = Histogram_database[yy][i];
                }
            }
        
            int asic01data[XSTRIPS] = {0};
            int asic23data[YSTRIPS] = {0};
            for(int i = 0; i < 64; i++)
            {
                asic01data[i] = asic0[i];
                asic01data[i+64] = asic1[i];
                asic23data[i] = asic3[i];//asic 3 on bottom
                asic23data[i+64] = asic2[i];//asic 2 on top
            }
     
     /*
            //finds the index values of the nside data that are above the given threshold
            //true if above, false if below
            bool asic01index[XSTRIPS] = {false};//nside
            for(int i = 0; i < XSTRIPS; i++){
                if(asic01data[i] >= low_threshold)
                        asic01index[i] = true;
                else asic01index[i] = false;
            }
            
            //finds the index values of the pside data that are above the given threshold
            //true if above, false if below
            bool asic23index[YSTRIPS] = {false};//pside
            for(int i = 0; i < YSTRIPS; i++){
                if(asic23data[i] >= low_threshold)
                    asic23index[i] = true;
                else asic23index[i] = false;
            }
            
            for(int i = 0; i < XSTRIPS; i++)
            {
                for(int j = 0; j < YSTRIPS; j++)
                {
                    //either plots a pixel on the image or sets the pixel to black
                    if(asic01index[i] and asic23index[j])
                    {
                        detImage[i][j] = asic01data[i]*asic23data[j];
                        num_hits++;
                    }
                    else detImage[i][j] = 0;
            
                    //detImagemask[i][j] = 0;//xmask[i] * ymask[j];
            
                    //sets the image timer??
                    detImagetime[i][j] = clock();
                }
            }
      */
            
      /*
             //initializes array to store data from the x strip asics
             int xAbove[128];
             int yAbove[128];
             for(int i = 0; i < 128; i++){
                xAbove[i] = -1; //base value is -1
                yAbove[i] = -1;
             }
    
             //if the counts from the detector exceeds a given value, the data is kept
             //else the value stays as -1
             for(int i = 0; i < 128; i++){
                if(xtest[i] > 10000)
                    xAbove[i] = abs(xtest[i]);
                if(ytest[i] > 10000)
                    yAbove[i] = abs(ytest[i]);
             }
        */
        
            int nsideMax = asic01data[0];
            int nsideIndex = 0;
            for(int i = 0; i < XSTRIPS; i++)
            {
                if(nsideMax < asic01data[i]){
                    nsideMax = asic01data[i];
                    nsideIndex = i;
                }
            }
            int psideMax = asic23data[0];
            int psideIndex = 0;
            for(int i = 0; i < YSTRIPS; i++)
            {
                if(psideMax < asic23data[i]){
                    psideMax = asic23data[i];
                    psideIndex = i;
                }
            }
    
            for(int i = 0; i < XSTRIPS and nsideMax > low_threshold and psideMax > low_threshold; i++)
            {
                for(int j = 0; j < YSTRIPS; j++)
                {
                    //if both x and y are above the threshold, then that is considered a hit
                    if(i == nsideIndex and j == psideIndex)
                    {
                        detImage[i][j] = (asic01data[i]*asic23data[j])/100 ;
                        if(detImage[i][j] > 10000){
                             detImage[i][j] = 10000;
                            cout << "over 10000" << endl;
                        }
                        num_hits++;
                    }                    detImagetime[i][j] = clock();
                }
            }
    
        
        
            /*
             for(int i = 0; i<XSTRIPS; i++)
             {
                for(int j = 0; j<YSTRIPS; j++)
                {
                    detImage[i][j] = xstrips[i] * ystrips[j];
                    detImagemask[i][j] = xmask[i] * ymask[j];
                    detImagetime[i][j] = clock();
                    if(detImage[i][j] > low_threshold){num_hits++;}
                }
             }
             */
            pthread_mutex_lock( &timebinmutex);
            current_timebin += num_hits;
            pthread_mutex_unlock(&timebinmutex);
        }
	}
	
	if (data_source == 2) {
		// parse and display the data from the USB/ASIC connection
		unsigned short int tmp;
		unsigned voltage_status;
		unsigned voltage;
		// parse the buffer variable and update the display
		// some example code is below
		
		struct strip_data  // 2 bytes
		{
			unsigned data : 10;
			unsigned number : 6;
		};
		
		struct voltage_data {
			unsigned value: 12;
			unsigned status: 4;
		};
		
		strip_data strip;
		voltage_data volt;
		
		printf("sync: %x\n", buffer[0]);
		printf("counter: %x\n", buffer[4]);
		
		memcpy(&strip,&buffer[29],2);
		memcpy(&volt,&buffer[13],2);
		
		voltage_status = buffer[13] & 0xF;
		voltage = (buffer[13] >> 12) & 0xFFF;
		
		gui->nEventsDone->value(nreads); 
		
		gui->framenumOutput->value(frame[5]);
		//gui->ctsOutput->value(strip.number);
		gui->HVOutput->value(voltage);
		printf("voltage: %i status: %i", voltage, voltage_status);
		if (voltage_status == 1){gui->HVOutput->textcolor(FL_RED);}
		if (voltage_status == 2){gui->HVOutput->textcolor(FL_BLUE);}
		if (voltage_status == 4){gui->HVOutput->textcolor(FL_BLACK);}
		
		HistogramFunction[strip.data]++;
		tmp = arc4random() % 64 + 1;
		detImage[tmp][strip.number] = 1;
		detImagetime[tmp][strip.number] = clock();
	}

}

void data_set_datafilename(void)
{
	// Open a file to write the data to
	// Name of file is automatically set with current date
	struct tm *times;
	time_t ltime;
	
	// The directory the file will go in is set in the preferences
	gui->prefs->get("data_file_save_dir", data_file_save_dir, "./");
	
	gui->prefs->get("file_type", file_type, 0);
	
	char stringtemp[80];
	time(&ltime);
	times = localtime(&ltime);

	if (file_type == 0) {
		strftime(stringtemp,25,"data_%Y%m%d_%H%M%S.txt\0",times);
	}
	if (file_type == 1) {
		strftime(stringtemp,25,"data_%Y%m%d_%H%M%S.dat\0",times);
	}
	
	strncpy(dataFilename, data_file_save_dir, MAXPATH - 1);
	strcat(dataFilename, stringtemp);
	dataFilename[MAXPATH - 1] = '\0';
	printf("%s\n",dataFilename);

}

okCFrontPanel *data_initialize_formatter_FPGA(void)
{
	bool bresult;
	// Open the first XEM - try all board types.
	dev = new okCFrontPanel;
	
	if (okCFrontPanel::NoError != dev->OpenBySerial()) {
		delete dev;
		printf("Device could not be opened.  Is one connected?\n");
		return(0);
	}
	
	switch (dev->GetBoardModel()) {
		case okCFrontPanel::brdXEM3005:
			printf("                                        Found a device: XEM3005\n");
			break;
		default:
			printf("Unsupported device.\n");
			delete dev;
			return(NULL);
	}
	
	// Configure the PLL appropriately
	okCPLL22150 *pll = new okCPLL22150 ;
 	pll->SetReference(48.0f, false);
 	bresult = pll->SetVCOParameters(574, 105); // output 32 x 8.2 MHz - close to 8.192 MHz
	//cout << "Settin VCO Parameters " << bresult << endl;
 	pll->SetDiv1(okCPLL22150::DivSrc_VCO, 8);
	// 32.8 approcimately 16 x 2.048 MHz
 	pll->SetDiv2(okCPLL22150::DivSrc_VCO, 127);
 	pll->SetOutputSource(0, okCPLL22150::ClkSrc_Div2By2); // Xilinx pin A8 = SYS_CLK1 (clk1)
 	pll->SetOutputEnable(0, true);
 	pll->SetOutputSource(1, okCPLL22150::ClkSrc_Div1ByN); // Xilinx pin A8 = SYS_CLK1 (clk1)
 	pll->SetOutputEnable(1, true);
 	pll->SetOutputSource(2, okCPLL22150::ClkSrc_Div1ByN); // Xilinx pin E9 = SYS_CLK2 (clk2)
 	pll->SetOutputEnable(2, true);
 	pll->SetOutputSource(3, okCPLL22150::ClkSrc_Div1ByN); // p71 = SYS_CLK4
 	pll->SetOutputEnable(3, true);
 	pll->SetOutputSource(4, okCPLL22150::ClkSrc_Div1ByN); // p69 = SYS_CLK5
 	pll->SetOutputEnable(4, true);
 	pll->SetOutputSource(5, okCPLL22150::ClkSrc_Div2ByN); //p67 = SYS_CLK6
 	pll->SetOutputEnable(5, true);
	dev->SetPLL22150Configuration(*pll);
	
	// Get some general information about the XEM.
	printf("Device firmware version: %d.%d\n", dev->GetDeviceMajorVersion(), dev->GetDeviceMinorVersion());
	printf("Device serial number: %s\n", dev->GetSerialNumber().c_str());
	printf("Device ID string: %s\n", dev->GetDeviceID().c_str());
	
	// Download the configuration file.
	if (okCFrontPanel::NoError != dev->ConfigureFPGA(FORMATTER_CONFIGURATION_FILE)) {
		printf("FPGA configuration failed.\n");
		delete dev;
		return(0);
	}
	
	// Check for FrontPanel support in the FPGA configuration.
	if (false == dev->IsFrontPanelEnabled()) {
		printf("FrontPanel support is not enabled.\n");
		delete dev;
		return(0);
	}
	
	printf("FrontPanel support is enabled.\n");	
	return dev;
}

void data_set_histogram_asic()
{
    histogram_asic = gui->histogram_asic->value();
    //0 = all, 1 = asic0, 2 = asic1, 3 = asic2, 4 = asic3
    if(histogram_asic != 0)
        gui->histogram_stripNumber->activate();
    else {
        stripNumber = 0;
        gui->histogram_stripNumber->value(0);
        gui->histogram_stripNumber->deactivate();
    }
}

void data_histogram_stripNumber()
{
    stripNumber = gui->histogram_stripNumber->value();
    //0 = all strips, other numbers correspond to the strip of that number (i.e. 1 = strip 1...)
}

