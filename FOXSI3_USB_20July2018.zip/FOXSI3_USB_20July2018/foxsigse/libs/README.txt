Put libokFrontPanel.dylib into /usr/local/lib/
