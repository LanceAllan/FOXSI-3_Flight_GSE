//
//  FOXSI_AppDelegate.m
//  FOXSI Commander
//
//  Created by Steven Christe on 12/30/13.
//  Copyright (c) 2013 ehSwiss Studios. All rights reserved.
//

#import "FOXSI_AppDelegate.h"

@implementation FOXSI_AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
